<?php
	$connect = new PDO("sqlite:intranet.db");
	if($connect) {
		$grant = 0;
		if(isset($_POST["email"]) && isset($_POST["motdepasse"])) {
			$mail = $_POST["email"];
			$motDePasse = $_POST["motdepasse"];
		}else{
			die("Il ya un champ vide.");
		}

		$result = $connect -> query("SELECT email, password FROM utilisateurs LIMIT 10");
		while($ligne = $result -> fetch()) {
			if($ligne["email"] == $mail and $ligne["password"] == $motDePasse) {
				$grant = 1;
				break;
			}
		}
	}else{
		die($connect -> errorInfo());
	}
?>

<?php
	if($grant) {
		echo "<article>".
"<h1>Bienvenue sur l'intranet des hôpitaux d'Haïti<h1/>".
"<h6>Utilisateurs actifs</h6>".
"</article>";

	$connect = new PDO("sqlite:intranet.db");
		echo "<table border>".
		"<tr>".
		"<th>Nom</th><th>Prénom</th><th>Identifiant Clinique</th>".
		"</tr><tr>";

		$result = $connect -> query("SELECT last_name, first_name, identifiantClinique FROM utilisateurs LIMIT 10 OFFSET 10");
		while($ligne = $result -> fetch()) {
			printf("<tr><td>%s</td><td>%s</td><td>%s</td></tr>",$ligne["last_name"],$ligne["first_name"],$ligne["identifiantClinique"]);
		}
		echo "</tr></table>";
	}else{
		echo "<h1>Accès refusé</h1>";
	}
?>
